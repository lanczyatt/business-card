import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  baseUrl: string = 'https://reqres.in/api/users/'

  constructor(private httpClient: HttpClient) { }

  getUsers(pageNum: string, perPage: string) {
    const httpHeaders = new HttpHeaders();
    httpHeaders.append('content-type', 'application/json')

    let queryParams = {"page": pageNum,"per_page": perPage};

    return this.httpClient.get(this.baseUrl, { headers: httpHeaders, params: queryParams });
  }

  getSingleUser(id: number) {
    return this.httpClient.get(this.baseUrl + id  );
  }

  deleteUser(id: number) {
    return this.httpClient.delete(this.baseUrl + id  );
  }

  addUser(userObj: any){
    return this.httpClient.post<any>(this.baseUrl, userObj);
  }

  updateUser(id: number, userObj: any){
    return this.httpClient.put(this.baseUrl + id, userObj);
  }
}

