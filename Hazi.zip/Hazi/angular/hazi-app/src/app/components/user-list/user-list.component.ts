import { UserComponent } from './../user/user.component';
import { UsersService } from './../../users.service';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  userList: any;
  form: FormGroup;
  numbers = ['3', '6', '12'];
  singleView: boolean = false;
  userToView: any;

  /*   @ViewChild(UserComponent, { static: false }) singleCard: UserComponent;
   */
  constructor(private usersService: UsersService) {
    this.form = new FormGroup({
      perPage: new FormControl('12')
    });
  }

  ngOnInit(): void {
    this.showUsers("1", "12");
    this.form.get('perPage')?.valueChanges.subscribe(selectedValue => {
      this.showUsers('1', selectedValue);
    })
  }

  showUsers(pageNum: string, perPage: string) {

    this.usersService.getUsers(pageNum, perPage).subscribe(data => {
      this.userList = data;
      console.log(this.userList);
    })
  }

  onUserClicked(eventData: { clickedUser: any }) {
    this.singleView = true;
    this.userToView = eventData.clickedUser;

    console.log(this.singleView);
    console.log(this.userToView);
  }

  deleteUser(eventData: { deletedUserId: number }) {
    this.usersService.deleteUser(eventData.deletedUserId).subscribe(data => {
      console.log("user deleted: ", data);

      alert("User deleted successfully!");
    }, err => {
      alert("Unable to delete user");
      console.log(err);
    });

    document.getElementById(eventData.deletedUserId.toString())?.setAttribute('hidden', 'true');
  }

  prevPage() {

    let prevPage = 1;

    if (this.userList.total_pages === 1) {
      prevPage = 1;
    } else if (this.userList.page === 1) {
      prevPage = this.userList.page - 1;
    } else {
      prevPage = this.userList.page - 1;
    }

    this.showUsers(prevPage.toString(), this.userList.per_page)
  }

  nextPage() {
    let nextPage = 1;

    if (this.userList.total_pages === 1) {
      nextPage = 1;
    } else if (this.userList.page === this.userList.total_pages) {
      nextPage = this.userList.page - 1;
    } else {
      nextPage = this.userList.page + 1;
    }

    this.showUsers(nextPage.toString(), this.userList.per_page)
  }
}
