import { UsersService } from './../../users.service';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-single-user-card',
  templateUrl: './single-user-card.component.html',
  styleUrls: ['./single-user-card.component.scss']
})
export class SingleUserCardComponent implements OnInit {

  @Input() userToView: any;
  @Output() userDeleted = new EventEmitter<{ deletedUserId: number }>();

  currentUser: any;
  editMode: boolean;
  editForm: FormGroup;

  constructor(private usersService: UsersService) {
    this.editForm = new FormGroup({
      name: new FormGroup({
        first_name: new FormControl('', [Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20)]),
        last_name: new FormControl('', [Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20)])
      }),
      email: new FormControl('', [Validators.email,
      Validators.required]),

    });
  }

  ngOnInit(): void {
    this.editMode = false;
  }

  onDeleteUser(id: number) {
    this.userDeleted.emit({ deletedUserId: id });
  }

  editUser(id: number, userObj: any) {
    console.log(this.editForm.value);
    console.log(this.editForm.valid);
    this.usersService.updateUser(id, userObj).subscribe(data => {
      alert("User updated!");
      console.log("Updated user ", data);
    }, err => {
      alert("Unable to update user");
      console.log(err);
    }
    )
  }
}
