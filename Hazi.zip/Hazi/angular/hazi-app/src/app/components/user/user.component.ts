import { UsersService } from './../../users.service';
import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  @Input() user: any;
  @Output() userClicked = new EventEmitter<{ clickedUser: any }>();
  @Output() userDeleted = new EventEmitter<{ deletedUserId: number }>();

  userPicked = false;
  singleUser: any;
  selectedUser: any;

  constructor(private usersService: UsersService) { }

  ngOnInit(): void {
  }

  showDetails(id: number) {
    this.usersService.getSingleUser(id).subscribe(user => {
      console.log(user);
      this.singleUser = user;
      console.log(this.singleUser);
      this.userClicked.emit({ clickedUser: this.singleUser });
    })
    this.userPicked = true;
  }

  onDeleteUser(id: number) {
    this.userDeleted.emit({ deletedUserId: id });
  }
}
