import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup, } from '@angular/forms';
import { UsersService } from 'src/app/users.service';

@Component({
  selector: 'app-add-user-form',
  templateUrl: './add-user-form.component.html',
  styleUrls: ['./add-user-form.component.css']
})
export class AddUserFormComponent implements OnInit {

  urlap: FormGroup;

  constructor(private usersService: UsersService) {

    this.urlap = new FormGroup({
      name: new FormGroup({
        first_name: new FormControl('', [Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20)]),
        last_name: new FormControl('', [Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20)])
      }),
      email: new FormControl('', [Validators.email,
      Validators.required]),
    });
  }

  ngOnInit(): void {
  }

  submit(): void {
    console.log(this.urlap.value);
    console.log(this.urlap.valid);

    this.usersService.addUser(this.urlap.value).subscribe(data => {
      let user = data;
      console.log(Object.entries(user));
      alert("User created! \r\n" + "User ID: " + user.id + "\r\n" + "User created at: " + user.createdAt);
      console.log("Created user ", data);
    }, err => {
      alert("Unable to create user");
      console.log(err);
    })
  }


}
